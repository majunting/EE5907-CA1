# EE5907-CA1

This assignment is written in Python, and the file format is jupyter notebook.
The instructions to install and run jupter notebook can be found at https://unidata.github.io/online-python-training/notebook.html
To run the code sections, simply select the cell and click run, or choose cell - run all
The .mat file must be saved at the same location as the python notebook file for the program to read the file correctly

Ma Junting (A0144294A)
E0008325@u.nus.edu
30/09/2019
